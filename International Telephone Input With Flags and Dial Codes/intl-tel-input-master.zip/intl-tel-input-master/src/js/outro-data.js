
  if (typeof module === "object" && module.exports) module.exports = allCountries;
  else window.allCountries = allCountries;
})();
